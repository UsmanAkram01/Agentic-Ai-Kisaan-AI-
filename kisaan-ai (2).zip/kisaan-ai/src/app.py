"""KisaanAI — Streamlit Web Interface (v2)"""

import os
import json
from dotenv import load_dotenv
import streamlit as st

from agents.farm_assessor    import assess_farm
from agents.market_researcher import research_market
from agents.operations_planner import build_operations_plan
from agents.logistics_reviewer import review_operations
from agents.pest_analyzer    import analyze_pest
from agents.produce_grader   import grade_produce
from pdf_generator import (
    generate_planner_pdf,
    generate_pest_pdf,
    generate_grader_pdf,
)

load_dotenv()

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="KisaanAI",
    page_icon="🌾",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

/* ── Root variables ── */
:root {
    --bg-main:       #0B2612;
    --bg-card:       rgba(22, 86, 42, 0.18);
    --border-card:   rgba(200, 168, 75, 0.25);
    --text-main:     #E0EEE3;
    --text-muted:    #A8D4B0;
    --accent:        #27824A;
    --accent-hover:  #16562A;
    --accent-glow:   rgba(39, 130, 74, 0.4);
    --orange:        #C8A84B;
}

/* ── Background ── */
.stApp {
    background-color: var(--bg-main);
    background-image: 
        radial-gradient(ellipse 160% 120% at 20% 0%, #1C3B22 0%, transparent 50%),
        radial-gradient(at 100% 100%, rgba(39, 130, 74, 0.15) 0px, transparent 50%);
    font-family: 'Inter', sans-serif;
    color: var(--text-main);
}

/* ── Typography ── */
h1, h2, h3, h4, h5, h6 {
    font-family: 'Inter', sans-serif !important;
    font-weight: 700 !important;
    color: #FFFFFF !important;
    letter-spacing: -0.02em !important;
}

h1 {
    font-size: 3rem !important;
    background: linear-gradient(to right, #FFFFFF, #9CA3AF);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] {
    background: rgba(255, 255, 255, 0.03) !important;
    border-radius: 9999px !important;
    padding: 6px !important;
    gap: 8px !important;
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
    backdrop-filter: blur(12px) !important;
    display: flex;
    justify-content: center;
}
.stTabs [data-baseweb="tab"] {
    border-radius: 9999px !important;
    color: var(--text-muted) !important;
    font-weight: 500 !important;
    font-size: 0.95rem !important;
    padding: 10px 24px !important;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
    border: 1px solid transparent !important;
}
.stTabs [data-baseweb="tab"]:hover {
    color: #FFFFFF !important;
    background: rgba(255, 255, 255, 0.05) !important;
}
.stTabs [aria-selected="true"] {
    background: rgba(255, 255, 255, 0.1) !important;
    color: #FFFFFF !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2) !important;
}

/* ── Expanders ── */
.streamlit-expanderHeader {
    background: var(--bg-card) !important;
    border: 1px solid var(--border-card) !important;
    border-radius: 12px !important;
    color: #FFFFFF !important;
    font-weight: 500 !important;
    backdrop-filter: blur(8px) !important;
    transition: all 0.2s !important;
}
.streamlit-expanderHeader:hover {
    border-color: rgba(255, 255, 255, 0.2) !important;
    background: rgba(255, 255, 255, 0.08) !important;
}
.streamlit-expanderContent {
    background: rgba(0, 0, 0, 0.2) !important;
    border: 1px solid var(--border-card) !important;
    border-top: none !important;
    border-radius: 0 0 12px 12px !important;
    backdrop-filter: blur(4px) !important;
}

/* ── Forms & Inputs ── */
.stTextInput input,
.stTextArea textarea,
.stNumberInput input {
    background: rgba(0, 0, 0, 0.3) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    border-radius: 10px !important;
    color: #FFFFFF !important;
    font-size: 0.95rem !important;
    padding: 12px !important;
    transition: all 0.2s !important;
}
.stTextInput input:focus,
.stTextArea textarea:focus {
    border-color: var(--accent) !important;
    box-shadow: 0 0 0 3px rgba(200, 168, 75, 0.2) !important;
}
.stSelectbox > div > div {
    background: rgba(0, 0, 0, 0.3) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    border-radius: 10px !important;
    color: #FFFFFF !important;
}
label {
    color: var(--text-muted) !important;
    font-weight: 500 !important;
    font-size: 0.9rem !important;
    margin-bottom: 4px !important;
}

/* ── Primary Buttons ── */
button[kind="primary"],
.stButton button[kind="primary"] {
    background: var(--orange) !important;
    color: #0B2612 !important;
    font-weight: 600 !important;
    border: none !important;
    border-radius: 9999px !important;
    padding: 12px 32px !important;
    letter-spacing: 0.5px !important;
    box-shadow: 0 4px 14px rgba(200, 168, 75, 0.3) !important;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
}
button[kind="primary"]:hover {
    background: #B39540 !important;
    box-shadow: 0 6px 20px rgba(200, 168, 75, 0.4) !important;
    transform: translateY(-2px) !important;
}

/* ── Secondary Buttons ── */
.stDownloadButton button,
.stButton button[kind="secondary"] {
    background: rgba(255, 255, 255, 0.05) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    color: #FFFFFF !important;
    border-radius: 9999px !important;
    padding: 10px 24px !important;
    font-weight: 500 !important;
    transition: all 0.2s !important;
}
.stDownloadButton button:hover,
.stButton button[kind="secondary"]:hover {
    background: rgba(255, 255, 255, 0.1) !important;
    border-color: rgba(255, 255, 255, 0.2) !important;
    transform: translateY(-1px) !important;
}

/* ── Metrics ── */
[data-testid="stMetricValue"] {
    color: #FFFFFF !important;
    font-size: 2rem !important;
    font-weight: 700 !important;
    letter-spacing: -1px !important;
}
[data-testid="stMetricLabel"] {
    color: var(--text-muted) !important;
    font-size: 0.85rem !important;
    text-transform: uppercase !important;
    letter-spacing: 1px !important;
    font-weight: 600 !important;
}

/* ── Alerts & Status ── */
.stSuccess > div {
    background: rgba(16, 185, 129, 0.1) !important;
    border: 1px solid rgba(16, 185, 129, 0.2) !important;
    border-radius: 12px !important;
    color: #34D399 !important;
}
.stError > div {
    background: rgba(239, 68, 68, 0.1) !important;
    border: 1px solid rgba(239, 68, 68, 0.2) !important;
    border-radius: 12px !important;
    color: #F87171 !important;
}
.stWarning > div {
    background: rgba(245, 158, 11, 0.1) !important;
    border: 1px solid rgba(245, 158, 11, 0.2) !important;
    border-radius: 12px !important;
    color: #FBBF24 !important;
}
.stInfo > div {
    background: rgba(59, 130, 246, 0.1) !important;
    border: 1px solid rgba(59, 130, 246, 0.2) !important;
    border-radius: 12px !important;
    color: #60A5FA !important;
}

/* ── Dividers ── */
hr {
    border-color: rgba(255, 255, 255, 0.1) !important;
    margin: 24px 0 !important;
}

/* ── File Uploader ── */
[data-testid="stFileUploader"] {
    background: rgba(0, 0, 0, 0.2) !important;
    border: 2px dashed rgba(255, 255, 255, 0.15) !important;
    border-radius: 16px !important;
    padding: 24px !important;
    transition: all 0.2s !important;
}
[data-testid="stFileUploader"]:hover {
    border-color: rgba(255, 255, 255, 0.3) !important;
    background: rgba(255, 255, 255, 0.02) !important;
}

/* ── Cards & Containers ── */
div[data-testid="stVerticalBlock"] > div[style*="flex-direction: column;"] > div[data-testid="stVerticalBlock"] {
    background: var(--bg-card);
    border: 1px solid var(--border-card);
    border-radius: 16px;
    padding: 24px;
    backdrop-filter: blur(12px);
}

/* ── Toggle Switch (Radio) ── */
.stRadio > div {
    background: rgba(0, 0, 0, 0.3) !important;
    border-radius: 10px !important;
    padding: 8px !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
}
.stRadio label {
    color: #FFF !important;
}

/* ── Spinner ── */
.stSpinner > div > div {
    border-top-color: var(--orange) !important;
}
</style>
""", unsafe_allow_html=True)

# ── Hero header ───────────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align:center; padding: 16px 0 32px 0;">
    <div style="font-size:3.5rem; margin-bottom:8px;">🌾</div>
    <div style="font-family:'Inter',sans-serif; font-size:3rem;
                color:#C8A84B; font-weight:700; letter-spacing:-1px;">
        KisaanAI
    </div>
    <div style="color:#A8D4B0; font-size:1.1rem; margin-top:8px;
                font-family:'Inter',sans-serif; font-weight: 400;">
        Har kisaan ka apna AI mentor &nbsp;·&nbsp; Every farmer's own AI mentor
    </div>
</div>
""", unsafe_allow_html=True)

if not os.getenv("OPENAI_API_KEY"):
    st.error("⚠️ OPENAI_API_KEY not found. Please add it to your .env file.")
    st.stop()

tab_planner, tab_pest, tab_grade, tab_weather = st.tabs([
    "📅  Season Planner",
    "🔬  Pest Analyzer",
    "🏆  Produce Grader",
    "🌦️  Weather Map"
])


# ════════════════════════════════════════════════════════════════════════════════
# TAB 1 — SEASON PLANNER
# ════════════════════════════════════════════════════════════════════════════════
with tab_planner:
    st.subheader("Plan Your Full Farm Season")
    st.caption("Describe your farm and get a week-by-week AI action plan, "
               "post-harvest guide, and printable PDF summary.")

    with st.form("farm_form"):
        st.markdown("##### Tell us about your farm")
        col_a, col_b = st.columns(2)
        with col_a:
            location        = st.text_input("Farm location",   placeholder="e.g. Kasur, Punjab")
            crop            = st.text_input("Crop",            placeholder="e.g. wheat, cotton, mango")
            soil_type       = st.text_input("Soil type",       placeholder="e.g. loamy, sandy, clay")
        with col_b:
            land_size       = st.text_input("Land size (acres)", placeholder="e.g. 50")
            water_source    = st.text_input("Water source",    placeholder="e.g. canal, tube well, drip")
            goal            = st.text_input("Goal",            placeholder="e.g. reduce water bill")
        current_practices   = st.text_area(
            "Current farming practices",
            placeholder="e.g. flood irrigation, manual pesticide spraying, sell to local arthi",
            height=90,
        )
        col_c, col_d = st.columns(2)
        with col_c:
            budget   = st.number_input("Budget (PKR)", min_value=10_000, max_value=500_000,
                                       value=50_000, step=10_000)
        with col_d:
            timeline = st.selectbox("Season length (weeks)", options=[8, 12, 16, 20], index=1)
        submitted = st.form_submit_button("🚜  Plan My Season", type="primary")

    if submitted:
        missing = []
        if not location.strip():          missing.append("Location")
        if not land_size.strip():         missing.append("Land size")
        if not crop.strip():              missing.append("Crop")
        if not water_source.strip():      missing.append("Water source")
        if not current_practices.strip(): missing.append("Current practices")
        if not goal.strip():              missing.append("Goal")
        if missing:
            st.error(f"Please fill in: {', '.join(missing)}")
            st.stop()

        farm_input = {
            "location": location, "land_size_acres": land_size, "crop": crop,
            "water_source": water_source, "soil_type": soil_type or "unknown",
            "current_practices": current_practices, "goal": goal,
            "budget_pkr": str(budget), "timeline_weeks": str(timeline),
        }

        try:
            progress = st.progress(0, text="Assessing your farm profile…")
            assessment    = assess_farm(farm_input)
            progress.progress(25, text="Researching market opportunities…")
            opportunities = research_market(assessment)
            progress.progress(50, text="Building your week-by-week plan…")
            plan          = build_operations_plan(assessment, opportunities, timeline)
            progress.progress(75, text="Adding checkpoints and harvest strategy…")
            reviewed      = review_operations(plan, assessment)
            progress.progress(100, text="Done!")
            progress.empty()

            st.session_state["planner_result"]     = reviewed
            st.session_state["planner_assessment"] = assessment
            st.session_state["planner_plan"]       = plan
            st.rerun()

        except Exception as e:
            st.error(f"Something went wrong: {e}")
            st.stop()

    if "planner_result" in st.session_state:
        reviewed   = st.session_state["planner_result"]
        assessment = st.session_state["planner_assessment"]
        plan       = st.session_state["planner_plan"]

        # ── Summary banner ──
        st.success(reviewed["overall_feedback"])

        c1, c2, c3 = st.columns(3)
        c1.metric("Farmer Level",     assessment.get("level", "").upper())
        c2.metric("Plan Difficulty",  reviewed.get("difficulty_rating", ""))
        c3.metric("Focus",            plan.get("stack_focus", "")[:30] + "…")

        # ── Strong / weak ──
        col_sp, col_wa = st.columns(2)
        with col_sp:
            st.markdown("**✅ Strong practices**")
            for p in assessment.get("strong_practices", []):
                st.markdown(f"- {p}")
        with col_wa:
            st.markdown("**⚡ Areas to improve**")
            for w in assessment.get("weak_areas", []):
                st.markdown(f"- {w}")

        st.divider()

        # ── Weekly plan ──
        st.subheader("📆 Week-by-Week Farm Plan")
        for week in reviewed["weeks"]:
            wn    = week["week_number"]
            theme = week["theme"]
            with st.expander(f"Week {wn} — {theme}"):
                col_opp, col_del = st.columns(2)
                with col_opp:
                    st.markdown(f"**🌱 Opportunity**\n\n{week.get('opportunity', '')}")
                with col_del:
                    st.markdown(f"**🎯 Deliverable**\n\n{week.get('deliverable', '')}")
                st.markdown("**Goals this week:**")
                for g in week.get("goals", []):
                    st.markdown(f"- {g}")
                st.markdown("**Resources:** " + " · ".join(week.get("resources", [])))
                st.warning(f"**✅ Checkpoint:** {week.get('checkpoint', '')}")

        st.divider()

        # ── Final harvest strategy ──
        st.subheader("🌾 Final Harvest Strategy")
        cap = reviewed["final_harvest_strategy"]
        st.markdown(f"**{cap.get('title', '')}**")
        st.markdown(cap.get("description", ""))
        st.markdown(f"*Estimated hours: {cap.get('estimated_hours', '')}*")
        for i, req in enumerate(cap.get("requirements", []), 1):
            st.markdown(f"{i}. {req}")

        st.divider()

        # ── POST-HARVEST PLAN ─────────────────────────────────────────────────
        php = plan.get("post_harvest_plan")
        if php:
            st.subheader("🏪 Post-Harvest Plan")
            st.info(php.get("overview", ""))

            # — Medications & Treatments —
            meds = php.get("medications_and_treatments", [])
            if meds:
                st.markdown("#### 💊 Medications & Treatments")
                for m in meds:
                    with st.expander(f"{m.get('stage', '')} — {m.get('treatment', '')}"):
                        mc1, mc2 = st.columns(2)
                        mc1.metric("Product",  m.get("product", ""))
                        mc2.metric("Dosage",   m.get("dosage", ""))
                        mc1.metric("Timing",   m.get("timing", ""))
                        mc2.metric("Est. Cost (PKR)", str(m.get("cost_pkr_estimate", "")))
                        st.markdown(f"**Purpose:** {m.get('purpose', '')}")

            st.divider()

            # — Pesticide Prevention Timeline —
            pest_tl = php.get("pesticide_prevention_timeline", [])
            if pest_tl:
                st.markdown("#### 🚫 Pesticide Overuse & Residue Rejection Prevention")
                st.caption("Follow this timeline strictly to avoid export rejection and PHI violations.")
                sorted_pest = sorted(pest_tl,
                                     key=lambda x: x.get("weeks_before_harvest", 0),
                                     reverse=True)
                for pt in sorted_pest:
                    wbh   = pt.get("weeks_before_harvest", "?")
                    risk  = pt.get("residue_risk", "")
                    risk_color = "🔴" if "HIGH" in risk.upper() else (
                        "🟡" if "MEDIUM" in risk.upper() else "🟢")
                    with st.expander(
                        f"{risk_color} {wbh} weeks before harvest — {pt.get('action', '')}"
                    ):
                        avoid = ", ".join(pt.get("chemicals_to_avoid", []))
                        st.error(f"**Chemicals to AVOID:** {avoid}")
                        st.markdown(f"**Why:** {pt.get('reason', '')}")
                        st.warning(f"**Residue Risk:** {risk}")
                        st.success(f"**Safe Alternatives:** {pt.get('safe_alternatives', '')}")

            st.divider()

            # — Irrigation Prevention Timeline —
            irr_tl = php.get("irrigation_prevention_timeline", [])
            if irr_tl:
                st.markdown("#### 💧 Irrigation Management — Prevent Over & Under-Watering")
                st.caption("Stage-by-stage guide to avoid waterlogging and drought stress.")
                for stage in irr_tl:
                    critical = stage.get("critical_window", False)
                    badge    = "🔥 CRITICAL WINDOW" if critical else ""
                    label    = (f"{stage.get('crop_stage', '')} "
                                f"({stage.get('week_range', '')}) {badge}")
                    with st.expander(label):
                        ic1, ic2 = st.columns(2)
                        ic1.metric("Frequency",          stage.get("recommended_frequency", ""))
                        ic2.metric("Water Depth/Round",  f"{stage.get('water_depth_mm', '?')} mm")
                        st.markdown("**⬆️ Over-irrigation signs:**")
                        st.error(stage.get("over_irrigation_signs", ""))
                        st.markdown("**⬇️ Under-irrigation signs:**")
                        st.warning(stage.get("under_irrigation_signs", ""))
                        st.info(f"**Prevention tip:** {stage.get('prevention_tip', '')}")

            st.divider()

            # — Storage Recommendations —
            storage = php.get("storage_recommendations", [])
            if storage:
                st.markdown("#### 📦 Storage Recommendations")
                for r in storage:
                    with st.expander(f"Grade {r.get('grade', '?')} — {r.get('storage_type', '')}"):
                        sc1, sc2 = st.columns(2)
                        sc1.metric("Temperature",    f"{r.get('temperature_celsius', '?')}°C")
                        sc2.metric("Max Days",        str(r.get("max_storage_days", "?")))
                        sc1.metric("Packaging",      r.get("packaging", ""))
                        sc2.metric("Target Buyer",   r.get("target_buyer", ""))
                        if r.get("notes"):
                            st.caption(r["notes"])

        st.divider()

        # ── PDF Download ──
        st.markdown("#### 📥 Download Summary PDF")
        try:
            pdf_bytes = generate_planner_pdf(reviewed, assessment, plan)
            st.download_button(
                label="⬇️  Download Season Plan (PDF)",
                data=pdf_bytes,
                file_name=f"kisaan_season_plan_{plan.get('stack_focus', 'farm')[:20].replace(' ', '_')}.pdf",
                mime="application/pdf",
                help="Includes week-by-week plan, post-harvest guide, irrigation & pesticide timelines",
            )
        except Exception as e:
            st.caption(f"PDF unavailable: {e}")

        if st.button("🔄  Start Over", type="secondary"):
            for k in ["planner_result", "planner_assessment", "planner_plan"]:
                st.session_state.pop(k, None)
            st.rerun()


# ════════════════════════════════════════════════════════════════════════════════
# TAB 2 — PEST ANALYZER
# ════════════════════════════════════════════════════════════════════════════════
with tab_pest:
    st.subheader("Identify Pests & Diseases from a Photo")
    st.caption("Take a close-up of a damaged leaf, fruit, or stem. "
               "The AI identifies the pest and gives you the exact pesticide, dosage, and spray timing.")

    with st.form("pest_form"):
        pest_image = st.file_uploader(
            "Upload crop photo",
            type=["jpg", "jpeg", "png", "webp"],
            help="Close-up of the affected area works best",
        )
        pc1, pc2 = st.columns(2)
        with pc1:
            pest_crop     = st.text_input("Crop name (optional)",     placeholder="e.g. wheat, mango")
        with pc2:
            pest_location = st.text_input("Your location (optional)", placeholder="e.g. Multan, Punjab")
        pest_submitted = st.form_submit_button("🔬  Analyze Photo", type="primary")

    if pest_submitted:
        if not pest_image:
            st.error("Please upload a photo first.")
            st.stop()

        image_bytes = pest_image.read()
        st.image(pest_image, caption="Uploaded photo", use_container_width=True)

        with st.spinner("Analyzing for pests and diseases…"):
            try:
                result = analyze_pest(image_bytes, crop=pest_crop, location=pest_location)
            except Exception as e:
                st.error(f"Analysis failed: {e}")
                st.stop()

        st.session_state["pest_result"]   = result
        st.session_state["pest_crop"]     = pest_crop
        st.session_state["pest_location"] = pest_location

    if "pest_result" in st.session_state:
        result        = st.session_state["pest_result"]
        pest_crop     = st.session_state.get("pest_crop", "")
        pest_location = st.session_state.get("pest_location", "")

        if result.get("not_a_pest"):
            st.info(f"ℹ️ {result.get('explanation', 'No pest detected.')}")
        else:
            severity  = result.get("severity", "low")
            sev_icon  = {"low": "🟢", "moderate": "🟡",
                         "high": "🟠", "critical": "🔴"}.get(severity, "🟡")

            st.markdown(f"### {sev_icon} {result.get('pest_identified', 'Unknown pest')}")
            st.caption(
                f"Confidence: **{result.get('confidence', 'medium').upper()}**  ·  "
                f"Affected part: **{result.get('affected_part', 'unknown')}**  ·  "
                f"Severity: **{severity.upper()}**"
            )
            st.markdown(f"_{result.get('explanation', '')}_")

            if result.get("harvest_blocked"):
                phi = result.get("pre_harvest_interval_days", 0)
                st.error(f"🚫 **Harvest blocked for {phi} days** after spraying (pre-harvest interval).")

            st.divider()
            st.markdown("#### 💊 Recommended Treatment")
            tc1, tc2, tc3, tc4 = st.columns(4)
            tc1.metric("Pesticide",          result.get("recommended_pesticide", "—"))
            tc2.metric("Dosage (ml/acre)",   str(result.get("dosage_ml_per_acre", "—")))
            tc3.metric("Urgency",            result.get("urgency", "—"))
            tc4.metric("PHI (days)",         str(result.get("pre_harvest_interval_days", 0)))

            st.markdown(f"**⏰ Spray timing:** {result.get('spray_timing', '—')}")
            st.markdown(f"**⚠️ Warning:** {result.get('warning', '—')}")
            if result.get("alternative_if_unavailable"):
                st.info(f"**Alternative if unavailable:** {result['alternative_if_unavailable']}")

        st.divider()
        st.markdown("#### 📥 Download Summary PDF")
        try:
            pdf_bytes = generate_pest_pdf(result, crop=pest_crop, location=pest_location)
            st.download_button(
                label="⬇️  Download Pest Report (PDF)",
                data=pdf_bytes,
                file_name=f"kisaan_pest_report.pdf",
                mime="application/pdf",
            )
        except Exception as e:
            st.caption(f"PDF unavailable: {e}")


# ════════════════════════════════════════════════════════════════════════════════
# TAB 3 — PRODUCE GRADER
# ════════════════════════════════════════════════════════════════════════════════
with tab_grade:
    st.subheader("Grade Your Produce Before It Leaves the Farm")
    st.caption("Upload a photo of your harvest. The AI grades it A/B/C and tells you which buyers "
               "to target — before the arthi gets involved.")

    with st.form("grade_form"):
        grade_image = st.file_uploader(
            "Upload produce photo",
            type=["jpg", "jpeg", "png", "webp"],
            help="Spread produce out and photograph in good lighting",
        )
        gc1, gc2 = st.columns(2)
        with gc1:
            grade_crop     = st.text_input("Crop name (optional)",     placeholder="e.g. mango, tomato")
        with gc2:
            grade_location = st.text_input("Your location (optional)", placeholder="e.g. Tando Allahyar")
        grade_submitted = st.form_submit_button("🏆  Grade My Produce", type="primary")

    if grade_submitted:
        if not grade_image:
            st.error("Please upload a photo first.")
            st.stop()

        image_bytes = grade_image.read()
        st.image(grade_image, caption="Uploaded photo", use_container_width=True)

        with st.spinner("Grading your produce…"):
            try:
                result = grade_produce(image_bytes, crop=grade_crop, location=grade_location)
            except Exception as e:
                st.error(f"Grading failed: {e}")
                st.stop()

        st.session_state["grade_result"]   = result
        st.session_state["grade_crop"]     = grade_crop
        st.session_state["grade_location"] = grade_location

    if "grade_result" in st.session_state:
        result         = st.session_state["grade_result"]
        grade_crop     = st.session_state.get("grade_crop", "")
        grade_location = st.session_state.get("grade_location", "")

        if result.get("overall_quality") == "undetectable":
            st.warning(f"Could not grade: {result.get('explanation', 'Image unclear.')}")
        else:
            quality = result.get("overall_quality", "unknown")
            q_icon  = {"excellent": "🌟", "good": "✅",
                       "fair": "⚠️", "poor": "❌"}.get(quality, "📊")

            st.markdown(
                f"### {q_icon} {result.get('crop_identified', 'Produce')} "
                f"— {quality.upper()} quality"
            )
            st.caption(
                f"Harvest timing: **{result.get('harvest_timing', 'unknown')}**  ·  "
                f"Arthi rejection risk: **{result.get('arthi_risk', 'unknown').upper()}**"
            )
            st.markdown(f"_{result.get('explanation', '')}_")

            if result.get("do_not_mix"):
                st.error("🚫 **Separate grades NOW** — mixing will cost you the Grade A "
                         "premium at the mandi.")

            st.divider()
            st.markdown("#### 📊 Grade Breakdown")
            grade_colors = {"A": "🟢", "B": "🟡", "C": "🔴"}
            for grade in result.get("grades", []):
                g       = grade.get("grade", "?")
                pct     = grade.get("estimated_percentage", 0)
                premium = grade.get("price_premium_percent", 0)
                p_str   = f"+{premium}%" if premium > 0 else f"{premium}%"
                p_color = "green" if premium > 0 else ("red" if premium < 0 else "gray")
                with st.expander(
                    f"{grade_colors.get(g, '⚪')} Grade {g} — "
                    f"{pct}% of produce  ·  :{p_color}[{p_str} vs arthi]"
                ):
                    st.markdown(f"**What qualifies:** {grade.get('description', '—')}")
                    st.markdown(f"**Sell to:** {grade.get('recommended_buyer', '—')}")
                    st.markdown(f"**Packaging:** {grade.get('packaging_advice', '—')}")

            st.divider()
            st.info(f"**🚨 Immediate action:** {result.get('action_required', '—')}")

            # ── QR Traceability (FIXED: qr_data_points is always a list now) ──
            qr_points = result.get("qr_data_points", [])
            if qr_points:
                with st.expander("📋 QR Traceability Data — log these before dispatch"):
                    for point in qr_points:   # iterates strings, not characters
                        st.markdown(f"- {point}")

        st.divider()
        st.markdown("#### 📥 Download Summary PDF")
        try:
            pdf_bytes = generate_grader_pdf(result, crop=grade_crop, location=grade_location)
            st.download_button(
                label="⬇️  Download Grading Report (PDF)",
                data=pdf_bytes,
                file_name=f"kisaan_grading_report.pdf",
                mime="application/pdf",
            )
        except Exception as e:
            st.caption(f"PDF unavailable: {e}")

# ════════════════════════════════════════════════════════════════════════════════
# TAB 4 — WEATHER MAP
# ════════════════════════════════════════════════════════════════════════════════
with tab_weather:
    st.subheader("🌦️ Current Weather Map")
    st.caption("View weather and temperature patterns for your farming area.")

    import pydeck as pdk
    import pandas as pd
    import numpy as np
    import urllib.request
    import urllib.parse
    import json

    weather_location = st.text_input("Select Area/Location", placeholder="e.g. Kasur, Punjab")
    
    view_type = st.radio(
        "Select Map View",
        ["Weather pattern view", "Heat signatures / temperature pattern view"],
        horizontal=True
    )

    @st.cache_data(ttl=3600, show_spinner=False)
    def geocode_location(loc_name):
        default_lat, default_lon = 30.3753, 69.3451  # Center of Pakistan
        if not loc_name.strip():
            return default_lat, default_lon
        try:
            # Append Pakistan to narrow down search if not specified
            search_query = loc_name if "pakistan" in loc_name.lower() else f"{loc_name}, Pakistan"
            url = f"https://nominatim.openstreetmap.org/search?q={urllib.parse.quote(search_query)}&format=json&limit=1"
            req = urllib.request.Request(url, headers={'User-Agent': 'KisaanAI/1.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                if data:
                    return float(data[0]["lat"]), float(data[0]["lon"])
        except Exception:
            pass
        return default_lat, default_lon

    # Get dynamic coordinates based on location input
    lat, lon = geocode_location(weather_location)

    # Generate some random mock data points around the center
    num_points = 500
    df = pd.DataFrame({
        "lat": np.random.normal(lat, 0.5, num_points),
        "lon": np.random.normal(lon, 0.5, num_points),
        "temp": np.random.uniform(25, 45, num_points), # mock temp
        "humidity": np.random.uniform(30, 90, num_points)
    })

    # Assign colors based on humidity levels for the scatterplot
    df["color"] = df["humidity"].apply(
        lambda h: [240, 230, 140, 180] if h < 40 else 
                  ([173, 216, 230, 180] if h < 60 else 
                   ([65, 105, 225, 180] if h < 80 else [0, 0, 139, 180]))
    )

    if view_type == "Heat signatures / temperature pattern view":
        # Heatmap layer
        layer = pdk.Layer(
            "HeatmapLayer",
            df,
            opacity=0.8,
            get_position=["lon", "lat"],
            aggregation="MEAN",
            get_weight="temp",
            color_range=[
                [255, 255, 178],
                [254, 204, 92],
                [253, 141, 60],
                [240, 59, 32],
                [189, 0, 38],
            ],
            threshold=0.1,
            radiusPixels=40,
        )
        tooltip = {"text": "Heat Signature Region"}
        st.info("🔥 Showing heat signatures indicating current high temperature zones.")
        
        legend_html = """
        <div style="margin-top:4px; margin-bottom:16px; padding:12px; background:rgba(255,255,255,0.05); border-radius:8px;">
            <p style="margin-bottom:8px; font-weight:600; color:#E0EEE3;">Temperature Key (°C):</p>
            <div style="display:flex; gap:16px; flex-wrap:wrap; font-size:0.85rem; color:#A8D4B0;">
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:#FFFFB2; width:16px; height:16px; border-radius:4px;"></div> &lt; 30°C</div>
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:#FECC5C; width:16px; height:16px; border-radius:4px;"></div> 30 - 35°C</div>
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:#FD8D3C; width:16px; height:16px; border-radius:4px;"></div> 35 - 40°C</div>
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:#F03B20; width:16px; height:16px; border-radius:4px;"></div> 40 - 45°C</div>
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:#BD0026; width:16px; height:16px; border-radius:4px;"></div> &gt; 45°C</div>
            </div>
        </div>
        """
    else:
        # Scatterplot layer for weather patterns (e.g. cloud/rain cover)
        layer = pdk.Layer(
            "ScatterplotLayer",
            df,
            get_position=["lon", "lat"],
            get_fill_color="color",
            get_radius="humidity * 100",
            pickable=True,
        )
        tooltip = {"text": "Temp: {temp}°C\nHumidity: {humidity}%"}
        st.info("🌧️ Showing general weather patterns (humidity and cloud cover).")

        legend_html = """
        <div style="margin-top:4px; margin-bottom:16px; padding:12px; background:rgba(255,255,255,0.05); border-radius:8px;">
            <p style="margin-bottom:8px; font-weight:600; color:#E0EEE3;">Humidity / Rain Pattern Key:</p>
            <div style="display:flex; gap:16px; flex-wrap:wrap; font-size:0.85rem; color:#A8D4B0;">
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:rgba(240, 230, 140, 0.8); width:16px; height:16px; border-radius:8px;"></div> Dry (&lt; 40%)</div>
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:rgba(173, 216, 230, 0.8); width:16px; height:16px; border-radius:8px;"></div> Normal (40 - 60%)</div>
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:rgba(65, 105, 225, 0.8); width:16px; height:16px; border-radius:8px;"></div> Humid (60 - 80%)</div>
              <div style="display:flex; align-items:center; gap:6px;"><div style="background:rgba(0, 0, 139, 0.8); width:16px; height:16px; border-radius:8px;"></div> Very Wet (&gt; 80%)</div>
            </div>
        </div>
        """

    view_state = pdk.ViewState(
        latitude=lat,
        longitude=lon,
        zoom=7,
        pitch=45,
    )

    r = pdk.Deck(
        layers=[layer],
        initial_view_state=view_state,
        map_style="road",
        tooltip=tooltip
    )

    st.pydeck_chart(r)
    st.markdown(legend_html, unsafe_allow_html=True)

    st.markdown("### 🌡️ Area Temperature Information")
    wc1, wc2, wc3 = st.columns(3)
    wc1.metric("Current Temperature", f"{np.mean(df['temp']):.1f} °C", "+1.2 °C")
    wc2.metric("Average Humidity", f"{np.mean(df['humidity']):.1f} %", "-5 %")
    wc3.metric("Heat Index", "High", "Caution")
