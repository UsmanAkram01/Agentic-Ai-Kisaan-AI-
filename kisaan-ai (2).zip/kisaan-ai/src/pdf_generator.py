"""PDF Generator - Creates downloadable summary reports for KisaanAI results."""

import io
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

# ── Brand colours ──────────────────────────────────────────────────────────────
FOREST   = colors.HexColor("#0C3B1A")
LEAF     = colors.HexColor("#1A6B35")
MINT     = colors.HexColor("#2D9B5A")
GOLD     = colors.HexColor("#C8A84B")
CREAM    = colors.HexColor("#F5F0E8")
LIGHT_BG = colors.HexColor("#F0F7F2")
DARK_TXT = colors.HexColor("#1A2E1C")
GREY     = colors.HexColor("#6B7C6E")


def _base_styles():
    """Return a dict of named ParagraphStyles."""
    base = getSampleStyleSheet()
    s = {}

    s["title"] = ParagraphStyle(
        "KTitle", parent=base["Title"],
        fontSize=24, leading=28, textColor=FOREST,
        fontName="Helvetica-Bold", spaceAfter=4
    )
    s["subtitle"] = ParagraphStyle(
        "KSubtitle", parent=base["Normal"],
        fontSize=11, leading=14, textColor=GOLD,
        fontName="Helvetica", spaceAfter=16
    )
    s["h1"] = ParagraphStyle(
        "KH1", parent=base["Heading1"],
        fontSize=15, leading=18, textColor=FOREST,
        fontName="Helvetica-Bold", spaceBefore=14, spaceAfter=6,
        borderPad=4
    )
    s["h2"] = ParagraphStyle(
        "KH2", parent=base["Heading2"],
        fontSize=12, leading=15, textColor=LEAF,
        fontName="Helvetica-Bold", spaceBefore=10, spaceAfter=4
    )
    s["h3"] = ParagraphStyle(
        "KH3", parent=base["Heading3"],
        fontSize=10, leading=13, textColor=DARK_TXT,
        fontName="Helvetica-Bold", spaceBefore=6, spaceAfter=3
    )
    s["body"] = ParagraphStyle(
        "KBody", parent=base["Normal"],
        fontSize=10, leading=14, textColor=DARK_TXT,
        fontName="Helvetica", spaceAfter=6
    )
    s["small"] = ParagraphStyle(
        "KSmall", parent=base["Normal"],
        fontSize=9, leading=12, textColor=GREY,
        fontName="Helvetica", spaceAfter=4
    )
    s["bullet"] = ParagraphStyle(
        "KBullet", parent=base["Normal"],
        fontSize=10, leading=13, textColor=DARK_TXT,
        fontName="Helvetica", leftIndent=14, spaceAfter=3,
        bulletIndent=4
    )
    s["highlight"] = ParagraphStyle(
        "KHighlight", parent=base["Normal"],
        fontSize=10, leading=14, textColor=FOREST,
        fontName="Helvetica-Bold", backColor=LIGHT_BG,
        borderPad=6, spaceAfter=6
    )
    s["footer"] = ParagraphStyle(
        "KFooter", parent=base["Normal"],
        fontSize=8, leading=10, textColor=GREY,
        fontName="Helvetica", alignment=TA_CENTER
    )
    return s


def _header_block(story, s, title: str, subtitle: str):
    """Add a branded header block."""
    story.append(Paragraph("🌾 KisaanAI", s["title"]))
    story.append(Paragraph(title, s["h1"]))
    story.append(Paragraph(subtitle, s["subtitle"]))
    story.append(HRFlowable(width="100%", thickness=2, color=GOLD, spaceAfter=10))
    story.append(Paragraph(
        f"Generated: {datetime.now().strftime('%d %B %Y, %I:%M %p')}",
        s["small"]
    ))
    story.append(Spacer(1, 10))


def _divider(story, color=LEAF):
    story.append(HRFlowable(width="100%", thickness=0.5, color=color, spaceBefore=8, spaceAfter=8))


def _kv_table(data: list[tuple], col_widths=None) -> Table:
    """Build a compact key-value table, safely converting all items to strings."""
    col_widths = col_widths or [6 * cm, 11 * cm]
    # Ensure all items are strings to prevent 'list' object has no attribute 'wrapOn' errors
    safe_data = []
    for row in data:
        safe_row = []
        for item in row:
            if isinstance(item, list):
                safe_row.append(", ".join(str(i) for i in item))
            else:
                safe_row.append(str(item))
        safe_data.append(safe_row)

    table = Table(safe_data, colWidths=col_widths)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), LIGHT_BG),
        ("TEXTCOLOR",  (0, 0), (0, -1), FOREST),
        ("FONTNAME",   (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME",   (1, 0), (1, -1), "Helvetica"),
        ("FONTSIZE",   (0, 0), (-1, -1), 9),
        ("LEADING",    (0, 0), (-1, -1), 13),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING",   (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, LIGHT_BG]),
        ("GRID", (0, 0), (-1, -1), 0.3, GREY),
        ("ROUNDEDCORNERS", (0, 0), (-1, -1), [4, 4, 4, 4]),
    ]))
    return table


# ══════════════════════════════════════════════════════════════════════════════
# 1. SEASON PLANNER PDF
# ══════════════════════════════════════════════════════════════════════════════

def generate_planner_pdf(reviewed: dict, assessment: dict, plan: dict) -> bytes:
    """Generate a Season Planner summary PDF."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)
    s = _base_styles()
    story = []

    _header_block(story, s, "Season Plan Summary",
                  "Your AI-generated week-by-week farm operations plan")

    # Assessment overview
    story.append(Paragraph("Farm Assessment", s["h1"]))
    story.append(Paragraph(assessment.get("assessment_summary", ""), s["body"]))
    story.append(Spacer(1, 6))

    kv = [
        ("Farmer Level", assessment.get("level", "").upper()),
        ("Difficulty Rating", reviewed.get("difficulty_rating", "")),
        ("Stack Focus", plan.get("stack_focus", "")),
        ("Weekly Hours Est.", str(plan.get("weekly_hours", "")) + " hrs"),
        ("Total Weeks", str(plan.get("total_weeks", ""))),
    ]
    story.append(_kv_table(kv))
    story.append(Spacer(1, 8))

    # Strong practices / weak areas
    col2 = [6*cm, 11*cm]
    if assessment.get("strong_practices"):
        story.append(Paragraph("Strong Practices", s["h2"]))
        for p in assessment["strong_practices"]:
            story.append(Paragraph(f"• {p}", s["bullet"]))
    if assessment.get("weak_areas"):
        story.append(Paragraph("Areas to Improve", s["h2"]))
        for w in assessment["weak_areas"]:
            story.append(Paragraph(f"• {w}", s["bullet"]))

    story.append(Spacer(1, 6))
    story.append(Paragraph(reviewed.get("overall_feedback", ""), s["highlight"]))

    _divider(story, GOLD)

    # Week-by-week plan
    story.append(Paragraph("Week-by-Week Operations Plan", s["h1"]))
    for week in reviewed.get("weeks", []):
        wn = week.get("week_number", "?")
        theme = week.get("theme", "")
        story.append(Paragraph(f"Week {wn} — {theme}", s["h2"]))

        rows = [
            ("Opportunity", week.get("opportunity", "")),
            ("Deliverable", week.get("deliverable", "")),
            ("Checkpoint", week.get("checkpoint", "")),
        ]
        story.append(_kv_table(rows))

        goals = week.get("goals", [])
        if goals:
            story.append(Paragraph("Goals:", s["h3"]))
            for g in goals:
                story.append(Paragraph(f"• {g}", s["bullet"]))

        resources = week.get("resources", [])
        if resources:
            story.append(Paragraph(
                "Resources: " + " | ".join(resources), s["small"]))
        story.append(Spacer(1, 4))

    _divider(story)

    # Final harvest strategy
    cap = reviewed.get("final_harvest_strategy", {})
    if cap:
        story.append(Paragraph("Final Harvest Strategy", s["h1"]))
        story.append(Paragraph(cap.get("title", ""), s["h2"]))
        story.append(Paragraph(cap.get("description", ""), s["body"]))
        story.append(Paragraph(
            f"Estimated hours: {cap.get('estimated_hours', '?')}", s["small"]))
        story.append(Paragraph("Requirements:", s["h3"]))
        for i, req in enumerate(cap.get("requirements", []), 1):
            story.append(Paragraph(f"{i}. {req}", s["bullet"]))

    # Post-harvest plan
    php = plan.get("post_harvest_plan")
    if php:
        story.append(PageBreak())
        story.append(Paragraph("Post-Harvest Plan", s["h1"]))
        story.append(Paragraph(php.get("overview", ""), s["body"]))
        _divider(story)

        # Medications
        meds = php.get("medications_and_treatments", [])
        if meds:
            story.append(Paragraph("Medications & Treatments", s["h1"]))
            for m in meds:
                story.append(Paragraph(m.get("stage", ""), s["h2"]))
                rows = [
                    ("Treatment", m.get("treatment", "")),
                    ("Product", m.get("product", "")),
                    ("Dosage", m.get("dosage", "")),
                    ("Timing", m.get("timing", "")),
                    ("Purpose", m.get("purpose", "")),
                    ("Est. Cost (PKR)", str(m.get("cost_pkr_estimate", ""))),
                ]
                story.append(_kv_table(rows))
                story.append(Spacer(1, 6))

        _divider(story)

        # Pesticide prevention
        pest_tl = php.get("pesticide_prevention_timeline", [])
        if pest_tl:
            story.append(Paragraph("Pesticide Overuse & Residue Rejection Prevention", s["h1"]))
            for pt in sorted(pest_tl, key=lambda x: x.get("weeks_before_harvest", 0), reverse=True):
                wbh = pt.get("weeks_before_harvest", "?")
                story.append(Paragraph(f"{wbh} Weeks Before Harvest", s["h2"]))
                rows = [
                    ("Action", pt.get("action", "")),
                    ("Chemicals to Avoid", ", ".join(pt.get("chemicals_to_avoid", []))),
                    ("Reason", pt.get("reason", "")),
                    ("Residue Risk", pt.get("residue_risk", "")),
                    ("Safe Alternatives", pt.get("safe_alternatives", "")),
                ]
                story.append(_kv_table(rows))
                story.append(Spacer(1, 6))

        _divider(story)

        # Irrigation prevention
        irr_tl = php.get("irrigation_prevention_timeline", [])
        if irr_tl:
            story.append(Paragraph("Irrigation Management Timeline", s["h1"]))
            story.append(Paragraph(
                "Prevent over-irrigation (waterlogging, root rot) and "
                "under-irrigation (stress, yield loss).", s["body"]))
            for stage in irr_tl:
                crit = " [CRITICAL WINDOW]" if stage.get("critical_window") else ""
                story.append(Paragraph(
                    f"{stage.get('crop_stage', '')} ({stage.get('week_range', '')}){crit}", s["h2"]))
                rows = [
                    ("Watering Frequency",    stage.get("recommended_frequency", "")),
                    ("Water Depth per Round", f"{stage.get('water_depth_mm', '?')} mm"),
                    ("Over-Irrigation Signs", stage.get("over_irrigation_signs", "")),
                    ("Under-Irrigation Signs",stage.get("under_irrigation_signs", "")),
                    ("Prevention Tip",        stage.get("prevention_tip", "")),
                ]
                story.append(_kv_table(rows))
                story.append(Spacer(1, 6))

        _divider(story)

        # Storage recommendations
        storage = php.get("storage_recommendations", [])
        if storage:
            story.append(Paragraph("Storage Recommendations", s["h1"]))
            headers = ["Grade", "Storage Type", "Temp (°C)", "Max Days", "Packaging", "Buyer"]
            rows = [headers] + [
                [
                    str(r.get("grade", "")),
                    str(r.get("storage_type", "")),
                    str(r.get("temperature_celsius", "")),
                    str(r.get("max_storage_days", "")),
                    str(r.get("packaging", "")),
                    str(r.get("target_buyer", "")),
                ]
                for r in storage
            ]
            col_widths = [1.5*cm, 3.5*cm, 2*cm, 2*cm, 4*cm, 4*cm]
            tbl = Table(rows, colWidths=col_widths)
            tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, 0), FOREST),
                ("TEXTCOLOR",     (0, 0), (-1, 0), CREAM),
                ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE",      (0, 0), (-1, -1), 8),
                ("LEADING",       (0, 0), (-1, -1), 12),
                ("TOPPADDING",    (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ("LEFTPADDING",   (0, 0), (-1, -1), 5),
                ("ROWBACKGROUNDS",(0, 1), (-1, -1), [colors.white, LIGHT_BG]),
                ("GRID",          (0, 0), (-1, -1), 0.3, GREY),
            ]))
            story.append(tbl)

    # Footer
    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5, color=GREY))
    story.append(Paragraph("KisaanAI — Har kisaan ka apna AI mentor", s["footer"]))

    doc.build(story)
    return buf.getvalue()


# ══════════════════════════════════════════════════════════════════════════════
# 2. PEST ANALYZER PDF
# ══════════════════════════════════════════════════════════════════════════════

def generate_pest_pdf(result: dict, crop: str = "", location: str = "") -> bytes:
    """Generate a Pest Analysis summary PDF."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)
    s = _base_styles()
    story = []

    _header_block(story, s, "Pest & Disease Analysis Report",
                  f"Crop: {crop or 'unspecified'}  |  Location: {location or 'unspecified'}")

    if result.get("not_a_pest"):
        story.append(Paragraph("No Pest Detected", s["h1"]))
        story.append(Paragraph(result.get("explanation", ""), s["body"]))
    else:
        severity = result.get("severity", "low")
        sev_label = {"low": "LOW", "moderate": "MODERATE",
                     "high": "HIGH", "critical": "CRITICAL"}.get(severity, severity.upper())

        story.append(Paragraph(result.get("pest_identified", "Unknown Pest"), s["h1"]))
        story.append(Paragraph(result.get("explanation", ""), s["body"]))

        summary_rows = [
            ("Severity",             sev_label),
            ("Confidence",           result.get("confidence", "").upper()),
            ("Affected Part",        result.get("affected_part", "")),
            ("Urgency",              result.get("urgency", "")),
            ("Harvest Blocked",      "YES" if result.get("harvest_blocked") else "No"),
            ("Pre-Harvest Interval", f"{result.get('pre_harvest_interval_days', 0)} days"),
        ]
        story.append(_kv_table(summary_rows))
        story.append(Spacer(1, 10))

        if result.get("harvest_blocked"):
            story.append(Paragraph(
                f"HARVEST BLOCKED for {result.get('pre_harvest_interval_days', 0)} days "
                "after spraying (pre-harvest interval).", s["highlight"]))

        _divider(story, GOLD)
        story.append(Paragraph("Recommended Treatment", s["h1"]))
        treatment_rows = [
            ("Pesticide",            result.get("recommended_pesticide", "")),
            ("Dosage",               f"{result.get('dosage_ml_per_acre', '')} ml/acre"),
            ("Spray Timing",         result.get("spray_timing", "")),
            ("Warning",              result.get("warning", "")),
            ("Alternative Option",   result.get("alternative_if_unavailable", "N/A")),
        ]
        story.append(_kv_table(treatment_rows))

    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5, color=GREY))
    story.append(Paragraph("KisaanAI — Har kisaan ka apna AI mentor", s["footer"]))

    doc.build(story)
    return buf.getvalue()


# ══════════════════════════════════════════════════════════════════════════════
# 3. PRODUCE GRADER PDF
# ══════════════════════════════════════════════════════════════════════════════

def generate_grader_pdf(result: dict, crop: str = "", location: str = "") -> bytes:
    """Generate a Produce Grading summary PDF."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)
    s = _base_styles()
    story = []

    _header_block(story, s, "Produce Grading Report",
                  f"Crop: {crop or result.get('crop_identified', 'unspecified')}"
                  f"  |  Location: {location or 'unspecified'}")

    if result.get("overall_quality") == "undetectable":
        story.append(Paragraph("Could Not Grade", s["h1"]))
        story.append(Paragraph(result.get("explanation", ""), s["body"]))
    else:
        quality = result.get("overall_quality", "")
        story.append(Paragraph(
            f"{result.get('crop_identified', 'Produce')} — {quality.upper()} Quality",
            s["h1"]))
        story.append(Paragraph(result.get("explanation", ""), s["body"]))

        summary_rows = [
            ("Overall Quality",   quality.upper()),
            ("Harvest Timing",    result.get("harvest_timing", "")),
            ("Arthi Risk",        result.get("arthi_risk", "").upper()),
            ("Separate Grades?",  "YES — DO NOT MIX" if result.get("do_not_mix") else "No"),
            ("Immediate Action",  result.get("action_required", "")),
        ]
        story.append(_kv_table(summary_rows))
        story.append(Spacer(1, 10))

        if result.get("do_not_mix"):
            story.append(Paragraph(
                "SEPARATE GRADES BEFORE TRANSPORT — mixing loses you the Grade A premium.",
                s["highlight"]))

        _divider(story, GOLD)
        story.append(Paragraph("Grade Breakdown", s["h1"]))

        grade_headers = ["Grade", "% of Produce", "Premium vs Arthi", "Sell To", "Packaging"]
        grade_rows = [grade_headers] + [
            [
                f"Grade {g.get('grade', '?')}",
                f"{g.get('estimated_percentage', 0)}%",
                f"{'+' if g.get('price_premium_percent', 0) >= 0 else ''}"
                f"{g.get('price_premium_percent', 0)}%",
                g.get("recommended_buyer", ""),
                g.get("packaging_advice", ""),
            ]
            for g in result.get("grades", [])
        ]
        col_widths = [2*cm, 2.5*cm, 3*cm, 5*cm, 5*cm]
        tbl = Table(grade_rows, colWidths=col_widths)
        tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, 0), FOREST),
            ("TEXTCOLOR",     (0, 0), (-1, 0), CREAM),
            ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",      (0, 0), (-1, -1), 9),
            ("LEADING",       (0, 0), (-1, -1), 13),
            ("TOPPADDING",    (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING",   (0, 0), (-1, -1), 5),
            ("ROWBACKGROUNDS",(0, 1), (-1, -1), [colors.white, LIGHT_BG]),
            ("GRID",          (0, 0), (-1, -1), 0.3, GREY),
        ]))
        story.append(tbl)

        # QR data points
        qr_points = result.get("qr_data_points", [])
        if qr_points:
            _divider(story)
            story.append(Paragraph("QR Traceability Data", s["h1"]))
            story.append(Paragraph(
                "Log these fields in your dispatch QR code before transport:", s["body"]))
            for point in qr_points:
                story.append(Paragraph(f"• {point}", s["bullet"]))

    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=0.5, color=GREY))
    story.append(Paragraph("KisaanAI — Har kisaan ka apna AI mentor", s["footer"]))

    doc.build(story)
    return buf.getvalue()
