"""Logistics Reviewer Agent - Adds checkpoints and final harvest strategy."""

import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


def review_operations(plan: dict, assessment: dict) -> dict:
    """
    Review the operations plan, add testable checkpoints, and design final harvest strategy.

    plan: dict from build_operations_plan()
    assessment: dict from assess_farm()

    Returns dict with:
        - overall_feedback: 2-3 sentences on plan strengths
        - difficulty_rating: one of "too easy", "well balanced", "too hard"
        - weeks: same weeks list but with added 'checkpoint' key per week
        - final_harvest_strategy: dict with:
            - title: name of final strategy
            - description: what to execute in 3-4 sentences
            - requirements: list of 5-6 specific requirements
            - estimated_hours: integer
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    system_prompt = (
        "You are a Senior Supply Chain Auditor and Agricultural Mentor. Review the operations plan and "
        "add concrete testable checkpoints, then return ONLY a raw JSON object with no markdown and no "
        "explanation. Use these exact keys:\\n"
        "- overall_feedback: 2-3 sentences on the plan's strengths and any gaps\\n"
        "- difficulty_rating: one of 'too easy', 'well balanced', 'too hard'\\n"
        "- weeks: the same weeks list from the plan but with one extra key added to each week object:\\n"
        "  - checkpoint: a specific question or task the farmer must complete before moving to next week. "
        "    Must be concrete and testable, not vague. Example: 'Can you show a photo of 5 installed sensors "
        "    and a screenshot of the subsidy receipt?' NOT 'Review your progress.'\\n"
        "- final_harvest_strategy: a capstone object with:\\n"
        "  - title: name of the final harvest and sell strategy\\n"
        "  - description: what to build/execute in 3-4 sentences\\n"
        "  - requirements: list of 5-6 specific technical/business requirements\\n"
        "  - estimated_hours: integer\\n\\n"
        "Checkpoints must be realistic for a Pakistani farmer with the assessed skill level. "
        "Consider: internet outages, low digital literacy, reliance on WhatsApp, and need for visual proof."
    )

    user_message = (
        f"Farm Assessment: {assessment.get('assessment_summary', '')}\n"
        f"Farmer Level: {assessment.get('level', '')}\n"
        f"Weak Areas: {', '.join(assessment.get('weak_areas', []))}\n\n"
        f"Operations Plan:\n{json.dumps(plan, indent=2)}"
    )

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            temperature=0.3,
            max_tokens=2500
        )

        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)
        print("Review complete. Checkpoints added.")
        return result

    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse review JSON: {e}. Raw response: {raw}")
    except Exception as e:
        raise RuntimeError(f"Review failed: {e}")
