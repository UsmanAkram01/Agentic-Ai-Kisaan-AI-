"""Farm Assessor Agent - Diagnoses farm profile and determines quality gaps."""

import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


def assess_farm(farm_input: dict) -> dict:
    """
    Assess a farmer's current situation and return a structured diagnosis.

    farm_input keys:
        - location: str (e.g., "Kasur, Punjab")
        - land_size_acres: str (e.g., "50")
        - crop: str (e.g., "wheat")
        - water_source: str (e.g., "canal + tube well")
        - soil_type: str (e.g., "loamy")
        - current_practices: str (e.g., "flood irrigation, manual pesticide spraying")
        - goal: str (e.g., "reduce water bill and sell directly to flour mill")
        - budget_pkr: str (e.g., "50000")
        - timeline_weeks: str (e.g., "12")

    Returns dict with:
        - level: "traditional" | "semi-modern" | "modern"
        - strong_practices: list of str
        - weak_areas: list of str
        - recommended_crop_stack: str
        - assessment_summary: str (2-3 sentences)
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    system_prompt = (
        "You are a senior Pakistani Agricultural Extension Officer with 20 years of field experience "
        "in Punjab and Sindh. Assess the farmer's current situation and return ONLY a raw JSON object "
        "with no markdown and no explanation. Use these exact keys:\\n"
        "- level: one of 'traditional', 'semi-modern', 'modern'\\n"
        "- strong_practices: list of practices the farmer does well\\n"
        "- weak_areas: list of specific gaps or weaknesses\\n"
        "- recommended_crop_stack: the technology and market approach they should focus on\\n"
        "- assessment_summary: 2-3 sentences summarizing their profile and recommended path"
    )

    user_message = (
        f"Location: {farm_input.get('location', '')}\\n"
        f"Land Size: {farm_input.get('land_size_acres', '')} acres\\n"
        f"Crop: {farm_input.get('crop', '')}\\n"
        f"Water Source: {farm_input.get('water_source', '')}\\n"
        f"Soil Type: {farm_input.get('soil_type', '')}\\n"
        f"Current Practices: {farm_input.get('current_practices', '')}\\n"
        f"Goal: {farm_input.get('goal', '')}\\n"
        f"Budget: PKR {farm_input.get('budget_pkr', '')}\\n"
        f"Timeline: {farm_input.get('timeline_weeks', '')} weeks"
    )

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
            temperature=0.3,
            max_tokens=800,
        )

        raw = response.choices[0].message.content.strip()
        # Strip markdown
        raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)
        print(f"Assessment complete for: {farm_input.get('goal', 'unknown goal')}")
        return result

    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse assessment JSON: {e}. Raw response: {raw}")
    except Exception as e:
        raise RuntimeError(f"Assessment failed: {e}")
