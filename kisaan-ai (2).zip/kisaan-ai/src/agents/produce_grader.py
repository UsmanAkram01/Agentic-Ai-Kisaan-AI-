"""Produce Grader Agent - Grades produce quality from photo and routes to appropriate buyers."""

import os
import json
import re
import base64
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


def encode_image(image_bytes: bytes) -> str:
    """Convert raw image bytes to base64 string."""
    return base64.b64encode(image_bytes).decode("utf-8")


def _coerce_list(value, fallback=None) -> list:
    """
    Ensure a value is a list. Fixes the QR traceability bug where the LLM
    sometimes returns a plain string instead of a JSON array, causing Streamlit
    to iterate over individual characters (B, l, e, m, ...).
    """
    if value is None:
        return fallback or []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        parts = [p.strip() for p in re.split(r"[,\n]", value) if p.strip()]
        return parts if parts else [value]
    return [str(value)]


def grade_produce(image_bytes: bytes, crop: str = "", location: str = "") -> dict:
    """
    Analyze a produce photo and grade it A/B/C for market routing.

    Returns dict with:
        - crop_identified, overall_quality, harvest_timing
        - grades: list of {grade, estimated_percentage, description,
                           recommended_buyer, price_premium_percent, packaging_advice}
        - arthi_risk, action_required, do_not_mix
        - qr_data_points: LIST of strings (not a bare string)
        - explanation
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    context = ""
    if crop:
        context += f"The farmer says this is {crop}. "
    if location:
        context += f"Farm is in {location}, Pakistan. "

    system_prompt = (
        "You are a Pakistani Post-Harvest Quality Expert and Mandi Grader with 15 years of experience "
        "grading produce at Badami Bagh (Lahore), Jodia Bazaar (Karachi), and export processing units "
        "in Multan and Faisalabad. You know Pakistani export standards for UAE and EU markets, domestic "
        "supermarket requirements (CSD, Imtiaz, Metro), and how arthies evaluate and often reject produce "
        "to force distress sales. "
        "Analyze the produce photo and return ONLY a raw JSON object with no markdown, no explanation. "
        "Use exactly these keys: crop_identified, overall_quality, harvest_timing, grades (array), "
        "arthi_risk, action_required, do_not_mix, qr_data_points, explanation. "
        "CRITICAL: qr_data_points MUST be a JSON array of individual string items, never a single string. "
        'Correct: ["Farm: Kasur", "Crop: Mango", "Grade: A/B", "Date: today"]. '
        'Wrong: "Farm, Crop, Grade, Date". '
        "The grades array must have 2-3 objects. Each must include: grade, estimated_percentage, "
        "description, recommended_buyer, price_premium_percent, packaging_advice. "
        "If image is unclear, return overall_quality as 'undetectable'."
    )

    user_content = [
        {
            "type": "text",
            "text": (
                f"{context}Analyze this produce photo. Grade into quality tiers (A/B/C), "
                "estimate percentage in each grade, and advise which buyers to target in Pakistan."
            )
        },
        {
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{encode_image(image_bytes)}",
                "detail": "high"
            }
        }
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content}
            ],
            temperature=0.2,
            max_tokens=1200
        )

        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        result = json.loads(raw)

        # ── BUG FIX: always coerce qr_data_points to a proper list ─────────
        # Without this, if the LLM returns a bare string like "Blemishes, size…",
        # iterating over it in app.py yields single characters: B, l, e, m, …
        result["qr_data_points"] = _coerce_list(result.get("qr_data_points"))

        # Normalise grade percentages to sum to 100
        if "grades" in result:
            total = sum(g.get("estimated_percentage", 0) for g in result["grades"])
            if total != 100 and total > 0:
                for g in result["grades"]:
                    g["estimated_percentage"] = round(g["estimated_percentage"] * 100 / total)

        print(f"Grading complete. Crop: {result.get('crop_identified', 'unknown')}. "
              f"Overall: {result.get('overall_quality', 'unknown')}")
        return result

    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse grading JSON: {e}. Raw: {raw}")
    except Exception as e:
        raise RuntimeError(f"Produce grading failed: {e}")
