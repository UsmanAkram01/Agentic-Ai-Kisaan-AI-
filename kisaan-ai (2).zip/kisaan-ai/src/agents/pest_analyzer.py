"""Pest Analyzer Agent - Identifies pest/disease from crop photo and recommends targeted treatment."""

import os
import json
import base64
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


def encode_image(image_bytes: bytes) -> str:
    """Convert raw image bytes to base64 string."""
    return base64.b64encode(image_bytes).decode("utf-8")


def analyze_pest(image_bytes: bytes, crop: str = "", location: str = "") -> dict:
    """
    Analyze a crop photo to identify pest/disease and recommend treatment.

    Args:
        image_bytes: Raw bytes of the uploaded image (JPG/PNG)
        crop: Optional crop name to narrow identification (e.g. "wheat", "mango")
        location: Optional farmer location to suggest locally available pesticides

    Returns dict with:
        - pest_identified: common + scientific name
        - confidence: "high" | "medium" | "low"
        - affected_part: e.g. "leaf", "fruit", "stem", "root"
        - severity: "low" | "moderate" | "high" | "critical"
        - harvest_blocked: bool — true if pre-harvest interval enforced
        - recommended_pesticide: specific product name available in Pakistan
        - dosage_ml_per_acre: integer
        - spray_timing: optimal time of day + weather conditions
        - pre_harvest_interval_days: integer
        - urgency: action window (e.g. "spray within 48 hours")
        - warning: safety/weather caveat
        - alternative_if_unavailable: backup pesticide option
        - not_a_pest: bool — true if image shows nutrient deficiency or abiotic stress instead
        - explanation: 2-3 sentence plain-language summary for farmer
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    context = ""
    if crop:
        context += f"The farmer says this is a {crop} crop. "
    if location:
        context += f"The farm is located in {location}, Pakistan. "

    system_prompt = (
        "You are a Pakistani Agricultural Entomologist and Plant Pathologist with 20 years of field "
        "experience diagnosing crop pests and diseases across Punjab, Sindh, and KPK. You have deep "
        "knowledge of pest species that affect Pakistani crops: wheat, rice, cotton, sugarcane, mango, "
        "citrus, tomato, potato, onion, and chilli. You know which pesticides are registered and "
        "available in Pakistani markets (Syngenta, FMC, Bayer CropScience local distributors). "
        "Analyze the crop photo and return ONLY a raw JSON object with no markdown, no explanation, "
        "no preamble. Use exactly these keys: pest_identified, confidence, affected_part, severity, "
        "harvest_blocked, recommended_pesticide, dosage_ml_per_acre, spray_timing, "
        "pre_harvest_interval_days, urgency, warning, alternative_if_unavailable, not_a_pest, explanation. "
        "If the image is unclear or not a crop, set not_a_pest to true and explain in explanation. "
        "If it looks like nutrient deficiency rather than a pest, set not_a_pest to true and describe "
        "the deficiency instead."
    )

    user_content = [
        {
            "type": "text",
            "text": (
                f"{context}Please analyze this crop photo and identify any pest, disease, or "
                "abnormality. Provide specific treatment recommendations using pesticides available "
                "in Pakistani markets with exact dosages per acre."
            )
        },
        {
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{encode_image(image_bytes)}",
                "detail": "high"
            }
        }
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content}
            ],
            temperature=0.2,
            max_tokens=1000
        )

        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()
        result = json.loads(raw)

        # Enforce pre-harvest interval logic
        if result.get("pre_harvest_interval_days", 0) > 0:
            result["harvest_blocked"] = True

        print(f"Pest analysis complete. Identified: {result.get('pest_identified', 'unknown')}")
        return result

    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse pest analysis JSON: {e}. Raw: {raw}")
    except Exception as e:
        raise RuntimeError(f"Pest analysis failed: {e}")
