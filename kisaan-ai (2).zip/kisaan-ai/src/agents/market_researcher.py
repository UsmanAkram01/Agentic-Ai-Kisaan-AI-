"""Market Researcher Agent - Finds 8 market opportunities for the farmer."""

import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


def research_market(assessment: dict) -> list:
    """
    Research 8 market opportunities based on the farm assessment.

    assessment keys (from assess_farm):
        - level: str
        - strong_practices: list
        - weak_areas: list
        - recommended_crop_stack: str
        - assessment_summary: str

    Returns list of exactly 8 opportunity objects, each with:
        - title: short opportunity name
        - description: what the opportunity is in one sentence
        - skills_taught: list of 3-4 skills this teaches the farmer
        - difficulty: one of "easy", "medium", "hard"
        - estimated_hours: integer hours to complete
        - why_this_opportunity: one sentence explaining fit
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    system_prompt = (
        "You are a Pakistani Mandi Intelligence Researcher who tracks prices daily at Badami Bagh (Lahore), "
        "Jodia Bazaar (Karachi), and regional flour mills. Based on the farm assessment provided, find and "
        "return ONLY a raw JSON array with no markdown and no explanation. The array must contain exactly 8 "
        "opportunity objects. Each must have these exact keys:\\n"
        "- title: short opportunity name\\n"
        "- description: what the opportunity does in one sentence\\n"
        "- skills_taught: list of 3-4 specific skills this teaches the farmer\\n"
        "- difficulty: one of 'easy', 'medium', 'hard'\\n"
        "- estimated_hours: integer number of hours to complete\\n"
        "- why_this_opportunity: one sentence explaining why it fits this farmer\\n\\n"
        "Focus on: direct buyers (mills, exporters, processors), government subsidies, input supplier deals, "
        "logistics options, co-op opportunities, cold storage, quality certification, and digital marketplaces."
    )

    user_message = f"Farm Assessment:\\n{json.dumps(assessment, indent=2)}"

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            temperature=0.4,
            max_tokens=1500
        )

        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)

        if not isinstance(result, list):
            raise ValueError(f"Expected JSON array, got {type(result).__name__}")
        if len(result) != 8:
            raise ValueError(f"Expected exactly 8 opportunities, got {len(result)}")

        print("Research complete. 8 opportunities found.")
        return result

    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse market research JSON: {e}. Raw response: {raw}")
    except Exception as e:
        raise RuntimeError(f"Market research failed: {e}")
