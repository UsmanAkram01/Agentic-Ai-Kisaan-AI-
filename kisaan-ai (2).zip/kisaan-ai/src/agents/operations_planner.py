"""Operations Planner Agent - Builds week-by-week farm calendar + post-harvest plan."""

import os
import json
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()


def build_operations_plan(assessment: dict, opportunities: list, timeline_weeks: int) -> dict:
    """
    Build a week-by-week operations plan and a detailed post-harvest plan.

    assessment: dict from assess_farm()
    opportunities: list of dicts from research_market()
    timeline_weeks: int

    Returns dict with:
        - total_weeks, weekly_hours, stack_focus
        - weeks: list of week objects (week_number, theme, opportunity, goals,
                 deliverable, resources)
        - post_harvest_plan: dict with
            - overview: str
            - medications_and_treatments: list of treatment objects
            - pesticide_prevention_timeline: list of timeline objects
            - irrigation_prevention_timeline: list of stage objects
            - storage_recommendations: list of storage objects
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    system_prompt = (
        "You are an Agricultural Operations Manager who plans crop cycles for large farms in Pakistan. "
        "Using the assessment and opportunity list, build a structured week-by-week operations plan "
        "AND a comprehensive post-harvest plan. "
        "Return ONLY a raw JSON object with no markdown and no explanation. "
        "Use these exact top-level keys:\n"
        "- total_weeks: integer\n"
        "- weekly_hours: integer\n"
        "- stack_focus: string\n"
        "- weeks: list of week objects, each with:\n"
        "    week_number, theme, opportunity, goals (list of 3), deliverable, resources (list of 2-3)\n"
        "- post_harvest_plan: object with these keys:\n"
        "    - overview: 2-3 sentences on post-harvest strategy for this specific crop\n"
        "    - medications_and_treatments: array of objects, each with:\n"
        "        stage (e.g. 'Immediately after harvest'), treatment (name of procedure),\n"
        "        product (chemical/biological name), dosage (amount + unit),\n"
        "        timing (when exactly to apply), purpose (what it prevents),\n"
        "        cost_pkr_estimate (integer)\n"
        "    - pesticide_prevention_timeline: array of objects ordered from EARLIEST to harvest, each with:\n"
        "        weeks_before_harvest (integer), action (what to do),\n"
        "        chemicals_to_avoid (list of chemical names),\n"
        "        reason (why this matters for residue/export compliance),\n"
        "        residue_risk (LOW/MEDIUM/HIGH with consequence),\n"
        "        safe_alternatives (biological or lower-PHI options to use instead)\n"
        "    - irrigation_prevention_timeline: array of objects by crop growth stage, each with:\n"
        "        crop_stage (e.g. 'Germination/Seedling'), week_range (e.g. 'Week 1-2'),\n"
        "        recommended_frequency (how often to water),\n"
        "        water_depth_mm (integer, target per irrigation),\n"
        "        over_irrigation_signs (visual/physical symptoms to watch for),\n"
        "        under_irrigation_signs (visual/physical symptoms),\n"
        "        prevention_tip (1-2 sentence practical action),\n"
        "        critical_window (bool - is this a sensitive period?)\n"
        "    - storage_recommendations: array of objects, each with:\n"
        "        grade (A/B/C or 'All'), storage_type, temperature_celsius,\n"
        "        max_storage_days, packaging, target_buyer, notes\n\n"
        "Map opportunities to weeks agronomically. Start with setup, move to monitoring, "
        "end with harvest. Follow Pakistan's warabandi canal schedule. "
        "Ensure pesticide_prevention_timeline spans 8-12 weeks before harvest. "
        "Ensure irrigation_prevention_timeline covers all major crop growth stages. "
        "IMPORTANT: You MUST explicitly consider the current and upcoming weather/temperature patterns "
        "for the provided location in your weekly goals and post-harvest plans. Include specific mitigation strategies "
        "for issues like heatwaves, heavy rain, or frost if they are common for this crop and location."
    )

    opp_text = "\n".join(
        f"{i+1}. {o['title']} - {o['description']} "
        f"(difficulty: {o['difficulty']}, hours: {o['estimated_hours']})"
        for i, o in enumerate(opportunities)
    )

    user_message = (
        f"Assessment Summary: {assessment.get('assessment_summary', '')}\n"
        f"Recommended Stack: {assessment.get('recommended_crop_stack', '')}\n"
        f"Weak Areas: {', '.join(assessment.get('weak_areas', []))}\n"
        f"Crop: {assessment.get('crop', 'unspecified')}\n"
        f"Water Source: {assessment.get('water_source', 'canal')}\n"
        f"Timeline: {timeline_weeks} weeks\n\n"
        f"Opportunities to schedule:\n{opp_text}"
    )

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            temperature=0.3,
            max_tokens=3500
        )

        raw = response.choices[0].message.content.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)

        if not isinstance(result.get("weeks"), list):
            raise ValueError("Expected 'weeks' to be a list")
        if len(result["weeks"]) != timeline_weeks:
            raise ValueError(
                f"Expected {timeline_weeks} weeks, got {len(result['weeks'])}"
            )

        # Ensure post_harvest_plan exists with all required keys
        php = result.get("post_harvest_plan", {})
        for required_key in [
            "overview", "medications_and_treatments",
            "pesticide_prevention_timeline", "irrigation_prevention_timeline",
            "storage_recommendations"
        ]:
            if required_key not in php:
                php[required_key] = [] if required_key != "overview" else ""
        result["post_harvest_plan"] = php

        print(f"Operations plan built. {timeline_weeks} weeks + post-harvest plan included.")
        return result

    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse operations plan JSON: {e}. Raw: {raw}")
    except Exception as e:
        raise RuntimeError(f"Operations planning failed: {e}")
