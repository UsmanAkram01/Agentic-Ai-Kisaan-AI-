"""KisaanAI - Main CLI Pipeline
Wires all four agents together into a single execution flow.
"""

import os
from dotenv import load_dotenv

from agents.farm_assessor import assess_farm
from agents.market_researcher import research_market
from agents.operations_planner import build_operations_plan
from agents.logistics_reviewer import review_operations


def main():
    # Step 1: Load API key
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        raise EnvironmentError(
            "ERROR: OPENAI_API_KEY not found in environment. "
            "Please set it in your .env file or environment variables."
        )

    print("Setup complete. Key loaded.")
    print("=" * 60)

    # Step 2: Hardcoded test farmer
    test_farmer = {
        "location": "Kasur, Punjab",
        "land_size_acres": "50",
        "crop": "wheat",
        "water_source": "canal + tube well",
        "soil_type": "loamy",
        "current_practices": "flood irrigation, manual pesticide spraying, sells to arthi in Badami Bagh",
        "goal": "reduce water bill and sell directly to flour mill instead of arthi",
        "budget_pkr": "50000",
        "timeline_weeks": "12"
    }

    print(f"\nFarmer Profile: {test_farmer['location']}, {test_farmer['land_size_acres']} acres, {test_farmer['crop']}")
    print(f"Goal: {test_farmer['goal']}")
    print("=" * 60)

    try:
        # Agent 1: Assess
        print("\n[1/4] Assessing farm profile...")
        assessment = assess_farm(test_farmer)
        print(f"\nAssessment Result:")
        print(f"  Level: {assessment['level']}")
        print(f"  Stack: {assessment['recommended_crop_stack']}")
        print(f"  Summary: {assessment['assessment_summary']}")
        print("-" * 60)

        # Agent 2: Research
        print("\n[2/4] Researching market opportunities...")
        opportunities = research_market(assessment)
        print(f"\nFound {len(opportunities)} opportunities:")
        for i, opp in enumerate(opportunities, 1):
            print(f"  {i}. {opp['title']} ({opp['difficulty']}, {opp['estimated_hours']}h)")
        print("-" * 60)

        # Agent 3: Plan
        print("\n[3/4] Building operations plan...")
        timeline_weeks = int(test_farmer["timeline_weeks"])
        plan = build_operations_plan(assessment, opportunities, timeline_weeks)
        print(f"\nOperations plan built: {plan['total_weeks']} weeks, {plan['weekly_hours']} hrs/week")
        print(f"Focus: {plan['stack_focus']}")
        print("-" * 60)

        # Agent 4: Review
        print("\n[4/4] Reviewing and adding checkpoints...")
        reviewed = review_operations(plan, assessment)
        print(f"\nReview Result:")
        print(f"  Feedback: {reviewed['overall_feedback']}")
        print(f"  Difficulty: {reviewed['difficulty_rating']}")
        print(f"\nFinal Harvest Strategy: {reviewed['final_harvest_strategy']['title']}")
        print(f"  Hours: {reviewed['final_harvest_strategy']['estimated_hours']}")
        print(f"  Requirements: {len(reviewed['final_harvest_strategy']['requirements'])}")
        print("=" * 60)

        print("\nPipeline complete.")

    except Exception as e:
        print(f"\nPipeline failed: {e}")
        raise


if __name__ == "__main__":
    main()
