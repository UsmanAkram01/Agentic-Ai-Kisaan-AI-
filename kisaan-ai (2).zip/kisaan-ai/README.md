# 🌾 KisaanAI

**AI-powered farm operations system for Pakistan.**

KisaanAI is a multi-agent system that helps Pakistani farmers reduce waste, improve crop quality, and sell directly to buyers — eliminating middlemen and capturing fair prices.

---

## What It Solves

| Problem | KisaanAI Solution |
|---------|-------------------|
| 30–40% post-harvest losses | Farm-gate quality grading + cold storage booking |
| Arthi (middleman) exploitation | Direct mill/exporter contract matching |
| Pesticide overuse & residue rejection | AI pest identification + precision dosing |
| Flood irrigation waste | Soil moisture sensors + smart valve control |
| No logistics coordination | Price-aware truck booking + market routing |

---

## The 4 Agents

1. **Farm Assessor** — Diagnoses farm profile, identifies quality gaps
2. **Market Researcher** — Finds 8 market opportunities (buyers, subsidies, co-ops)
3. **Operations Planner** — Builds week-by-week crop calendar
4. **Logistics Reviewer** — Adds testable checkpoints + final harvest strategy

---

## Setup

```bash
# 1. Clone / unzip the project
cd kisaan-ai

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Add your OpenAI API key
cp .env.example .env
# Edit .env and set: OPENAI_API_KEY=sk-...
```

---

## Usage

### CLI Pipeline (test mode)

```bash
python src/main.py
```

Runs all 4 agents with a hardcoded test farmer profile and prints results.

### Web UI

```bash
streamlit run src/app.py
```

Opens a browser form where farmers enter their profile and get a full season plan.

---

## Project Structure

```
kisaan-ai/
├── src/
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── farm_assessor.py         # Agent 1: Diagnose
│   │   ├── market_researcher.py     # Agent 2: Find opportunities
│   │   ├── operations_planner.py    # Agent 3: Build calendar
│   │   └── logistics_reviewer.py    # Agent 4: Validate + checkpoints
│   ├── main.py                      # CLI pipeline
│   └── app.py                       # Streamlit UI
├── .env                             # Your API key (gitignored)
├── .env.example                     # Template
├── requirements.txt                 # Dependencies
└── README.md                        # This file
```

---

## Tech Stack

- **OpenAI GPT-4o-mini** — LLM engine for all 4 agents
- **python-dotenv** — Environment management
- **Streamlit** — Farmer-facing web UI

---

## No Hardcoded Keys

All API keys load from `.env`. Never commit your `.env` file.

---

## License

MIT
