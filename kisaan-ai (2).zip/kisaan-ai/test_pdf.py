import json
from src.pdf_generator import generate_planner_pdf

reviewed = {
    "difficulty_rating": "Easy",
    "overall_feedback": "Looks good",
    "weeks": [
        {
            "week_number": 1,
            "theme": "Start",
            "opportunity": "Yes",
            "deliverable": "Done",
            "checkpoint": "Ok",
            "goals": ["Goal 1"],
            "resources": ["Res 1"]
        }
    ],
    "final_harvest_strategy": {
        "title": "Strategy",
        "description": "Desc",
        "estimated_hours": 10,
        "requirements": ["Req 1"]
    }
}
assessment = {
    "assessment_summary": "Summary",
    "level": "Pro",
    "strong_practices": ["Strong"],
    "weak_areas": ["Weak"]
}
plan = {
    "stack_focus": "Focus",
    "weekly_hours": 5,
    "total_weeks": 10,
    "post_harvest_plan": {
        "overview": "Overview",
        "medications_and_treatments": [
            {
                "stage": "Stage 1",
                "treatment": "Treat",
                "product": "Prod",
                "dosage": "1ml",
                "timing": "Now",
                "purpose": "Purp",
                "cost_pkr_estimate": 100
            }
        ],
        "pesticide_prevention_timeline": [
            {
                "weeks_before_harvest": 2,
                "action": "Act",
                "chemicals_to_avoid": ["Chem1"],
                "reason": "Res",
                "residue_risk": "High",
                "safe_alternatives": "Safe"
            }
        ],
        "irrigation_prevention_timeline": [
            {
                "critical_window": True,
                "crop_stage": "Stage",
                "week_range": "1-2",
                "recommended_frequency": "Freq",
                "water_depth_mm": 10,
                "over_irrigation_signs": "Over",
                "under_irrigation_signs": "Under",
                "prevention_tip": "Tip"
            }
        ],
        "storage_recommendations": [
            {
                "grade": "A",
                "storage_type": "Cold",
                "temperature_celsius": 4,
                "max_storage_days": 10,
                "packaging": "Box",
                "target_buyer": "Buyer"
            }
        ]
    }
}

with open("test.pdf", "wb") as f:
    f.write(generate_planner_pdf(reviewed, assessment, plan))
print("Success")
